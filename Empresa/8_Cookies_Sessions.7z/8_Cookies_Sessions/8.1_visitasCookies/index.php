<?php 

    $n ;
    if(!empty($_COOKIE))
    {
        $n = $_COOKIE['galleta'] + 1;
    }

    if (!empty($_COOKIE)) 
    {
        setcookie('galleta',$n);
        $imprimir = ($_COOKIE['galleta']);
    }
    else 
    {
        setcookie('galleta',1 ) ;
        header("Location: ./index.php");
   
    }
     
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> <?php if (!empty($imprimir)){echo($imprimir);}?></h1>

    <form action="./borrarCookie.php" method="post">
        <input type="submit" value=true name='borrar'> BorrarCookie
    </form>
</body>
</html>