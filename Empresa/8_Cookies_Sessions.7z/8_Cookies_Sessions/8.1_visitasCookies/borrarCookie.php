<?php

function borrarCookie()
{
    if(!empty($_POST) && $_POST['borrar'] == 'true' )
    {
    setcookie('galleta','');
    var_dump($_COOKIE);
    $_POST['borrar'] == false;
    header("Location: ./index.php");
    }
}

borrarCookie();
?>