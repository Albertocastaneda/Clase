<?php 
//Control de idioma 
function getData()
{
    if (!empty($_POST['language']))
    {
        setcookie('language',$_POST['language']);
        return $_POST['language'];
    }
    else if (!empty($_POST['borrar']))
    {
        $_POST['borrar'] = false;
    }
    
}


function controlIdioma($idioma)
{
    switch (strtolower($idioma)) 
    {
        case 'spanish':
             header("Location: ./es.html");
            break;
        case 'english':
             header("Location: ./en.html");
            break;
        case 'french':
             header("Location: ./fr.html");
            break;
    }
}

controlIdioma(getData());

?>