<?php
//Borra las cookies y redirecciona a index.php

function borrarCookie()
{
    if(!empty($_POST) && $_POST['borrar'] == 'true' )
    {
    setcookie('language','');
    $_POST['borrar'] == false;
    header("Location: ./index.php");
    }
}
borrarCookie();
?>